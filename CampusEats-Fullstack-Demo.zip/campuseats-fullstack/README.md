# Campus Eats Full-Stack Demo

This bundle combines the supplied Campus Eats frontend with the supplied Node/Express/PostgreSQL backend.

## Local run
1. Create a PostgreSQL database.
2. Copy `.env.example` to `.env` and set `DATABASE_URL` and `JWT_SECRET`.
3. `npm install`
4. `npm start`
5. Open `http://localhost:4000`

The app auto-creates its schema and seeds the Tubatsi menu/buildings on startup.

### Demo staff login
Default shift passcode: `comrades_2026` (change `DEMO_STAFF_PASSCODE` before any real deployment).

## Railway
Create a Railway project, add PostgreSQL, deploy this folder, and set `JWT_SECRET` plus `DEMO_STAFF_PASSCODE`. Railway supplies `DATABASE_URL` when Postgres is connected.
