# Campus Eats — Integrated Static Prototype

Open `index.html` to launch the customer website.

Connected demo flow:

- Customer homepage → menu → persistent cart → login/register → checkout → order tracking
- Staff Portal → staff login → staff order dashboard
- Orders created at checkout are saved in browser `localStorage` and appear in the staff dashboard in the same browser.
- Staff status changes are reflected on the tracking page.

## Staff demo passcode

`comrades_2026`

## Important

This is a static front-end prototype. Authentication, passwords, payments, SMS, file uploads and order persistence are **not production-secure** without a real backend/database.
